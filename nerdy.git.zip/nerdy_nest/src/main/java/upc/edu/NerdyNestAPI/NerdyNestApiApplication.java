package upc.edu.NerdyNestAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NerdyNestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(NerdyNestApiApplication.class, args);
	}

}
