package upc.edu.NerdyNestAPI.inventario.dto;

import lombok.Data;

@Data
public class CategoryRequest {
    private String name;
}
