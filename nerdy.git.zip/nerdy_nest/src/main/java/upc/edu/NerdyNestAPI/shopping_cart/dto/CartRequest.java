package upc.edu.NerdyNestAPI.shopping_cart.dto;

import lombok.Data;

@Data
public class CartRequest {
    private Integer quantity;
}
