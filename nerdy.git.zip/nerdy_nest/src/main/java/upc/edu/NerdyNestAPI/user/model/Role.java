package upc.edu.NerdyNestAPI.user.model;

public enum Role {
    CLIENT,
    ADMIN,
    UNAUTHORIZED
}
